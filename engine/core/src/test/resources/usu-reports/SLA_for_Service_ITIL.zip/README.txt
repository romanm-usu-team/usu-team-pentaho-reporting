Steps to generate datasource for "SLA for Service"
==================================================
All steps are done in Valuemation rich client with debugging flag set:
Path = ServiceManager.setting, parameter = instantiation.debugging

1) select a Service Template which will act as main object for SLA:
		- it has some Calculation Results created
		- it has some subordinated services (hierarchy)
		- it has one ore more Service Parameters created
	- link one or more persons (Assigned Persons) with roles to the service
	- assign a pricing modsel (at last one price condition must have all attributes filled!)
	- generate some Service Instances, assign one or more business partners
	- select "Standard SLA Document" and finish the instantiation wizard
2) go to "Service Agrrements - Top only" catalog, select all items
	- export XML data using filter "SLA for Service"

Run Valuemation Jetty / Tomcat client:
3) in the SA catalog, select the SA used in during instantiation
	- run "Print with Service Intelligence", select the business partner
	- choose format PDF, finish process
	- in you tmp folder, open file Pentaho_dump.xml (debugging = 1)
	- there are all data created in run time
4) open / unpack the datasource "SLA_for_Service_ITIL.zip"
	- compare ServiceAgreement.xml and content of Pentaho_dump.xml
	- add missing data from XML_dump to ServiceAgreement.xml
	- pack ServiceAgreement.xml back to zip file

Now you can use this file as data source in Pentaho Report Designer.
